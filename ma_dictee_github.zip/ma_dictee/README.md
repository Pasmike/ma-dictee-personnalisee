# 📝 Ma Dictée Personnalisée

Application Flutter de dictée interactive multilingue avec correction automatique et suivi de progression.

## ✨ Fonctionnalités

- 🌍 **15 langues** : Français, Anglais, Espagnol, Allemand, Arabe, Portugais, Italien, Néerlandais, Chinois, Japonais, Coréen, Turc, Russe, Swahili, Hindi
- 🎯 **3 niveaux** : Débutant, Intermédiaire, Avancé
- 🔊 **Synthèse vocale** pour écouter chaque dictée
- ✅ **Correction automatique** mot par mot avec score en pourcentage
- 📊 **Historique des sessions** sauvegardé sur l'appareil

## 🛠️ Technologies utilisées

- [Flutter](https://flutter.dev) (Dart)
- [flutter_tts](https://pub.dev/packages/flutter_tts) — Synthèse vocale
- [shared_preferences](https://pub.dev/packages/shared_preferences) — Sauvegarde locale
- [percent_indicator](https://pub.dev/packages/percent_indicator) — Jauge de score animée

## 🚀 Installation (pour les développeurs)

```bash
# Cloner le projet
git clone https://github.com/TON_NOM/ma-dictee-personnalisee.git

# Aller dans le dossier
cd ma-dictee-personnalisee

# Installer les dépendances
flutter pub get

# Lancer en mode développement
flutter run
```

## 📦 Compiler pour le Play Store

```bash
flutter clean
flutter pub get
dart run flutter_launcher_icons
flutter build appbundle --release
```

Le fichier `.aab` sera dans `build/app/outputs/bundle/release/`.

## 📄 Politique de confidentialité

Cette application ne collecte aucune donnée personnelle. Toutes les données restent sur l'appareil de l'utilisateur.

## 👤 Auteur

Développé par [Ton Nom] — [contact@exemple.com]

---

*Disponible sur le Google Play Store*
