# ════════════════════════════════════════════════════════
# proguard-rules.pro
#
# ProGuard est un outil qui "compresse" ton application en
# supprimant tout le code inutilisé avant de la publier.
# C'est bien pour la taille du fichier final, MAIS parfois
# ProGuard supprime du code qui était en réalité nécessaire.
#
# Ces règles lui disent : "ne touche pas à ces classes,
# même si tu penses qu'elles ne sont pas utilisées."
# ════════════════════════════════════════════════════════

# Protège les classes du moteur Flutter
-keep class io.flutter.** { *; }
-dontwarn io.flutter.**

# Protège la bibliothèque flutter_tts (synthèse vocale)
-keep class com.tundralabs.fluttertts.** { *; }

# Protège shared_preferences (sauvegarde des scores)
-keep class androidx.preference.** { *; }

# Règle générale : ne pas avertir sur les classes manquantes
# dans les bibliothèques tierces (normal et sans danger)
-dontwarn **
