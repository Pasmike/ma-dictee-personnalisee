import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ════════════════════════════════════════════════════════
// POINT D'ENTRÉE DE L'APPLICATION
// C'est la première fonction appelée au démarrage.
// ════════════════════════════════════════════════════════

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ma Dictée Personnalisée',
      // debugShowCheckedModeBanner: false retire le bandeau rouge "debug"
      // qui apparaîtrait sur les captures d'écran du Play Store.
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true, // Interface moderne recommandée par Google
      ),
      home: const LanguageSelectionScreen(),
    );
  }
}

// ════════════════════════════════════════════════════════
// DONNÉES CENTRALISÉES
// Regrouper toutes les données ici (langues, textes) facilite
// la maintenance : si tu veux ajouter une langue ou un texte,
// tu n'as qu'un seul endroit à modifier dans tout le code.
// ════════════════════════════════════════════════════════

const Map<String, String> kLanguages = {
  'Français': 'fr-FR',
  'Anglais': 'en-US',
  'Espagnol': 'es-ES',
  'Allemand': 'de-DE',
  'Arabe': 'ar-SA',
  'Portugais': 'pt-PT',
  'Italien': 'it-IT',
  'Néerlandais': 'nl-NL',
  'Chinois': 'zh-CN',
  'Japonais': 'ja-JP',
  'Coréen': 'ko-KR',
  'Turc': 'tr-TR',
  'Russe': 'ru-RU',
  'Swahili': 'sw',
  'Hindi': 'hi-IN',
};

// Textes de dictée organisés par langue ET par niveau.
// C'est le cœur pédagogique de l'application.
// Tu peux enrichir cette liste autant que tu veux !
const Map<String, Map<String, String>> kDictationTexts = {
  'Français': {
    'Débutant': 'Le chat dort sur le canapé. Il fait beau aujourd\'hui.',
    'Intermédiaire':
        'La révolution numérique transforme nos habitudes quotidiennes de manière profonde.',
    'Avancé':
        'L\'épistémologie interroge les fondements et la validité de la connaissance humaine.',
  },
  'Anglais': {
    'Débutant': 'The dog runs in the park. She likes to play with a ball.',
    'Intermédiaire':
        'Technology has dramatically changed the way we communicate with each other.',
    'Avancé':
        'The philosopher questioned the epistemological foundations of empirical knowledge.',
  },
  'Espagnol': {
    'Débutant': 'El gato duerme en el sofá. Hoy hace buen tiempo.',
    'Intermédiaire':
        'La tecnología digital ha transformado profundamente nuestras costumbres diarias.',
    'Avancé':
        'La epistemología cuestiona los fundamentos y la validez del conocimiento humano.',
  },
  'Allemand': {
    'Débutant': 'Die Katze schläft auf dem Sofa. Heute ist schönes Wetter.',
    'Intermédiaire':
        'Die digitale Revolution verändert unsere täglichen Gewohnheiten grundlegend.',
    'Avancé':
        'Die Erkenntnistheorie hinterfragt die Grundlagen und Gültigkeit menschlichen Wissens.',
  },
  'Italien': {
    'Débutant': 'Il gatto dorme sul divano. Oggi fa bel tempo.',
    'Intermédiaire':
        'La rivoluzione digitale trasforma profondamente le nostre abitudini quotidiane.',
    'Avancé':
        'L\'epistemologia interroga i fondamenti e la validità della conoscenza umana.',
  },
  'Portugais': {
    'Débutant': 'O gato dorme no sofá. Hoje está bom tempo.',
    'Intermédiaire':
        'A revolução digital transforma profundamente os nossos hábitos quotidianos.',
    'Avancé':
        'A epistemologia questiona os fundamentos e a validade do conhecimento humano.',
  },
};

// Fonction utilitaire : retourne le texte correspondant à une langue
// et un niveau, avec un texte par défaut si la combinaison n'existe pas.
String getDictationText(String language, String level) {
  return kDictationTexts[language]?[level] ??
      'Bienvenue dans Ma Dictée Personnalisée. '
          'Écoutez attentivement et écrivez ce que vous entendez.';
}

// ════════════════════════════════════════════════════════
// MODÈLE DE DONNÉES : UNE SESSION DE DICTÉE
// Représenter une session comme un objet dédié permet de la
// sauvegarder proprement et de l'afficher dans l'historique.
// ════════════════════════════════════════════════════════

class DictationSession {
  final String language;
  final String level;
  final int score; // Pourcentage de 0 à 100
  final int correctWords;
  final int totalWords;
  final DateTime date;

  DictationSession({
    required this.language,
    required this.level,
    required this.score,
    required this.correctWords,
    required this.totalWords,
    required this.date,
  });

  // Conversion en JSON pour la sauvegarde sur l'appareil
  Map<String, dynamic> toJson() => {
        'language': language,
        'level': level,
        'score': score,
        'correctWords': correctWords,
        'totalWords': totalWords,
        'date': date.toIso8601String(),
      };

  // Reconstruction depuis le JSON sauvegardé
  factory DictationSession.fromJson(Map<String, dynamic> json) =>
      DictationSession(
        language: json['language'],
        level: json['level'],
        score: json['score'],
        correctWords: json['correctWords'],
        totalWords: json['totalWords'],
        date: DateTime.parse(json['date']),
      );
}

// ════════════════════════════════════════════════════════
// SERVICE DE SAUVEGARDE DES SCORES
// Isoler la logique de stockage ici est une bonne pratique :
// si tu changes de système de stockage plus tard, tu ne
// modifies que cette classe, sans toucher au reste.
// ════════════════════════════════════════════════════════

class ScoreService {
  static const _key = 'dictation_sessions';

  // Charge toutes les sessions sauvegardées, triées du plus récent au plus ancien
  static Future<List<DictationSession>> loadSessions() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw
        .map((s) => DictationSession.fromJson(jsonDecode(s)))
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  // Sauvegarde une nouvelle session (en gardant les 50 dernières maximum)
  static Future<void> saveSession(DictationSession session) async {
    final prefs = await SharedPreferences.getInstance();
    final sessions = await loadSessions();
    sessions.insert(0, session);
    final limited = sessions.take(50).toList();
    await prefs.setStringList(
      _key,
      limited.map((s) => jsonEncode(s.toJson())).toList(),
    );
  }
}

// ════════════════════════════════════════════════════════
// ÉCRAN 1 : SÉLECTION DE LA LANGUE
// ════════════════════════════════════════════════════════

class LanguageSelectionScreen extends StatelessWidget {
  const LanguageSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🌍 Choisissez une langue'),
        centerTitle: true,
      ),
      body: ListView.separated(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: kLanguages.length,
        // separatorBuilder ajoute une ligne fine entre chaque élément
        // pour améliorer la lisibilité sans alourdir l'interface.
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final entry = kLanguages.entries.elementAt(index);
          return ListTile(
            leading: const Icon(Icons.language),
            title: Text(entry.key),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => LevelSelectionScreen(
                  language: entry.key,
                  ttsLang: entry.value,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ════════════════════════════════════════════════════════
// ÉCRAN 2 : SÉLECTION DU NIVEAU
// ════════════════════════════════════════════════════════

class LevelSelectionScreen extends StatelessWidget {
  final String language;
  final String ttsLang;

  const LevelSelectionScreen({
    super.key,
    required this.language,
    required this.ttsLang,
  });

  // Associer une couleur à chaque niveau aide l'utilisateur à comprendre
  // la progression d'un seul coup d'œil (vert = facile, rouge = difficile).
  Color _levelColor(String level) {
    switch (level) {
      case 'Débutant':
        return Colors.green;
      case 'Intermédiaire':
        return Colors.orange;
      case 'Avancé':
        return Colors.red;
      default:
        return Colors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    final levels = ['Débutant', 'Intermédiaire', 'Avancé'];
    return Scaffold(
      appBar: AppBar(
        title: Text('Niveau — $language'),
        centerTitle: true,
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: levels.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final level = levels[index];
          return Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: _levelColor(level),
                child: Text(
                  '${index + 1}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              title: Text(
                level,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => DictationScreen(
                    language: language,
                    ttsLang: ttsLang,
                    level: level,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ════════════════════════════════════════════════════════
// ÉCRAN 3 : LA DICTÉE (cœur de l'application)
// Cet écran DOIT être un StatefulWidget car il gère plusieurs
// états qui changent au fil du temps :
//   1. Est-ce que le TTS est en train de lire ?
//   2. Quel texte l'utilisateur a-t-il saisi ?
//   3. Quel est le résultat de la correction ?
// ════════════════════════════════════════════════════════

class DictationScreen extends StatefulWidget {
  final String language;
  final String ttsLang;
  final String level;

  const DictationScreen({
    super.key,
    required this.language,
    required this.ttsLang,
    required this.level,
  });

  @override
  State<DictationScreen> createState() => _DictationScreenState();
}

class _DictationScreenState extends State<DictationScreen> {
  final FlutterTts _tts = FlutterTts();
  final TextEditingController _controller = TextEditingController();

  bool _isSpeaking = false;
  bool _corrected = false;
  List<MapEntry<String, bool>> _wordResults = [];
  int _score = 0;
  int _correctWords = 0;

  late final String _dictationText;

  @override
  void initState() {
    super.initState();
    // On récupère le texte de la dictée une seule fois à l'initialisation
    _dictationText = getDictationText(widget.language, widget.level);

    // Configuration du TTS : on le prépare une fois ici, pas à chaque appui
    _tts.setLanguage(widget.ttsLang);
    _tts.setSpeechRate(0.45); // Un peu plus lent que la normale pour une dictée

    // Ces callbacks mettent à jour l'icône du bouton (lecture / arrêt)
    _tts.setStartHandler(() => setState(() => _isSpeaking = true));
    _tts.setCompletionHandler(() => setState(() => _isSpeaking = false));
    _tts.setErrorHandler((_) => setState(() => _isSpeaking = false));
  }

  @override
  void dispose() {
    // IMPORTANT : toujours libérer les ressources quand l'écran est fermé
    // pour éviter les fuites mémoire.
    _tts.stop();
    _controller.dispose();
    super.dispose();
  }

  // Bascule entre lecture et arrêt
  Future<void> _toggleSpeech() async {
    if (_isSpeaking) {
      await _tts.stop();
      setState(() => _isSpeaking = false);
    } else {
      await _tts.speak(_dictationText);
    }
  }

  // Nettoie un mot : minuscules + suppression de la ponctuation
  // Exemple : "bonjour," devient "bonjour"
  String _clean(String word) =>
      word.toLowerCase().replaceAll(RegExp(r'[^\w]'), '');

  // Algorithme de correction : compare mot par mot, calcule un score
  Future<void> _correctDictation() async {
    final originalWords = _dictationText
        .split(' ')
        .map(_clean)
        .where((w) => w.isNotEmpty)
        .toList();

    final userWords = _controller.text
        .split(' ')
        .map(_clean)
        .where((w) => w.isNotEmpty)
        .toList();

    final results = <MapEntry<String, bool>>[];
    for (int i = 0; i < originalWords.length; i++) {
      final expected = originalWords[i];
      final given = i < userWords.length ? userWords[i] : '___';
      results.add(MapEntry(expected, given == expected));
    }

    final correct = results.where((e) => e.value).length;
    final score = originalWords.isEmpty
        ? 0
        : (correct / originalWords.length * 100).round();

    // Sauvegarde automatique de cette session dans l'historique
    await ScoreService.saveSession(DictationSession(
      language: widget.language,
      level: widget.level,
      score: score,
      correctWords: correct,
      totalWords: originalWords.length,
      date: DateTime.now(),
    ));

    setState(() {
      _wordResults = results;
      _score = score;
      _correctWords = correct;
      _corrected = true;
    });
  }

  // La couleur change selon la performance : vert si bon, rouge si faible
  Color get _scoreColor {
    if (_score >= 80) return Colors.green;
    if (_score >= 50) return Colors.orange;
    return Colors.red;
  }

  String get _scoreMessage {
    if (_score == 100) return '🏆 Parfait ! Bravo !';
    if (_score >= 80) return '🎉 Excellent travail !';
    if (_score >= 50) return '👍 Bien, continue à t\'entraîner !';
    return '💪 Courage, réessaie !';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.language} — ${widget.level}'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'Historique',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => const ScoreHistoryScreen()),
            ),
          ),
        ],
      ),
      // SingleChildScrollView évite le débordement quand le clavier
      // virtuel apparaît et réduit l'espace disponible à l'écran.
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // ── Bouton écouter / arrêter ──
            ElevatedButton.icon(
              onPressed: _toggleSpeech,
              icon: Icon(_isSpeaking ? Icons.stop : Icons.volume_up),
              label: Text(_isSpeaking ? 'Arrêter' : 'Écouter la dictée'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                textStyle: const TextStyle(fontSize: 16),
              ),
            ),

            const SizedBox(height: 24),

            const Text(
              'Écris ce que tu entends :',
              style:
                  TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),

            TextField(
              controller: _controller,
              maxLines: 6,
              enabled: !_corrected, // Bloque la saisie après correction
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Ta dictée ici...',
              ),
            ),

            const SizedBox(height: 16),

            if (!_corrected)
              ElevatedButton.icon(
                onPressed: _correctDictation,
                icon: const Icon(Icons.check_circle_outline),
                label: const Text('Corriger ma dictée'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),

            // ── Zone de résultat (visible uniquement après correction) ──
            if (_corrected) ...[
              const SizedBox(height: 24),

              // Jauge circulaire animée avec le score
              Center(
                child: CircularPercentIndicator(
                  radius: 80,
                  lineWidth: 12,
                  percent: _score / 100,
                  center: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '$_score%',
                        style: TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: _scoreColor,
                        ),
                      ),
                      Text(
                        '$_correctWords/${_wordResults.length}',
                        style: const TextStyle(
                            fontSize: 13, color: Colors.grey),
                      ),
                    ],
                  ),
                  progressColor: _scoreColor,
                  backgroundColor: Colors.grey.shade200,
                  animation: true,
                  animationDuration: 1000,
                ),
              ),

              const SizedBox(height: 12),

              Text(
                _scoreMessage,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: _scoreColor,
                ),
              ),

              const SizedBox(height: 24),

              const Text(
                'Détail de la correction :',
                style: TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),

              // Wrap affiche les mots sur plusieurs lignes naturellement
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: _wordResults.map((entry) {
                  return Chip(
                    label: Text(entry.key),
                    backgroundColor: entry.value
                        ? Colors.green.shade100
                        : Colors.red.shade100,
                    side: BorderSide(
                      color: entry.value ? Colors.green : Colors.red,
                    ),
                    avatar: Icon(
                      entry.value ? Icons.check : Icons.close,
                      size: 16,
                      color: entry.value ? Colors.green : Colors.red,
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 24),

              // Bouton pour recommencer la même dictée
              OutlinedButton.icon(
                onPressed: () {
                  setState(() {
                    _controller.clear();
                    _corrected = false;
                    _wordResults = [];
                    _score = 0;
                    _correctWords = 0;
                  });
                },
                icon: const Icon(Icons.refresh),
                label: const Text('Recommencer'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════
// ÉCRAN 4 : HISTORIQUE DES SCORES
// ════════════════════════════════════════════════════════

class ScoreHistoryScreen extends StatefulWidget {
  const ScoreHistoryScreen({super.key});

  @override
  State<ScoreHistoryScreen> createState() => _ScoreHistoryScreenState();
}

class _ScoreHistoryScreenState extends State<ScoreHistoryScreen> {
  // FutureBuilder nous permet d'afficher un indicateur de chargement
  // le temps que les données soient lues depuis la mémoire de l'appareil.
  late Future<List<DictationSession>> _sessionsFuture;

  @override
  void initState() {
    super.initState();
    _sessionsFuture = ScoreService.loadSessions();
  }

  Color _scoreColor(int score) {
    if (score >= 80) return Colors.green;
    if (score >= 50) return Colors.orange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('📊 Historique des scores'),
        centerTitle: true,
      ),
      body: FutureBuilder<List<DictationSession>>(
        future: _sessionsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final sessions = snapshot.data ?? [];
          if (sessions.isEmpty) {
            return const Center(
              child: Text(
                'Aucune session pour l\'instant.\nFais ta première dictée !',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: sessions.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final s = sessions[index];
              final color = _scoreColor(s.score);
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: color.withOpacity(0.15),
                  child: Text(
                    '${s.score}%',
                    style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
                title: Text('${s.language} — ${s.level}'),
                subtitle: Text(
                  '${s.correctWords}/${s.totalWords} mots · '
                  '${s.date.day}/${s.date.month}/${s.date.year}',
                ),
                trailing: SizedBox(
                  width: 60,
                  child: LinearProgressIndicator(
                    value: s.score / 100,
                    color: color,
                    backgroundColor: color.withOpacity(0.15),
                    minHeight: 6,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
